# Serverless CATS@Notes application

A simple application to take notes !

#### Maintainers

Send us an [email][Email] if you have any questions.

[Email]: mailto:jean-pierre.cordeiro@ca-ts.fr


